package TestTest;

public interface TestInterface1 {
}
