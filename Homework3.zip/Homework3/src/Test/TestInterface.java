package Test;

public interface TestInterface {
}
